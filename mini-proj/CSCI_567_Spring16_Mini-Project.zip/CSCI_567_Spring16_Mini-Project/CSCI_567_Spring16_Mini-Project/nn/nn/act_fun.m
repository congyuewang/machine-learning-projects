%% Activation Function
function fx = act_fun(x)
    
        fx = 1./(1 + exp(-x)); %Binary
   
end