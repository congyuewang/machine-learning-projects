
function fx_drev = act_fun_diff(fx)
   
        fx_drev = fx .* (1 - fx);
    
end